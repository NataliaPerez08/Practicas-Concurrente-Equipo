public class Constante {
    // Constantes de configuración
    public static final int NUM_PRISIONEROS = 10; // Número de prisioneros
    public static final int NUM_PASADAS_MAX = 5; // Número máximo de pasadas por prisionero
    public static final int NUM_PASADAS_TOTALES = NUM_PRISIONEROS * NUM_PASADAS_MAX; // Número total de pasadas
    public static final int NUM_MAX_INTENTOS = 3; // Número máximo de intentos para verificar si han pasado todos
}
