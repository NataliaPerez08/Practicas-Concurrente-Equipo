package kass.concurrente;
import kass.concurrente.tenedor.TenedorImpl;
import kass.concurrente.invitados.Inversionista;

public class Main {
    public static void main(String[] args) {
        System.out.println("Bienvenidos al Hoyo de Kassandra");//Investiguen la referencia, quien la diga primero en discord, se lleva participacion

        System.out.println("Prueba tenedorImpl");
        TenedorImpl tenedor = new TenedorImpl(1);
        tenedor.tomar();
        tenedor.soltar();
        Inversionista[] inversionistas = new Inversionista[4];
        

        
    }
}