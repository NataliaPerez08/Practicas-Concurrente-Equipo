package kass.concurrente.candadosImpl;

import kass.concurrente.candados.Semaphore;

/**
 * Clase que modela el Algoritmo del Filtro Modificado
 * Este algoritmo es similar al del filtro, lo diferente es que
 * permite una cantidad m de hilos SIMULTANEOS en la seccion critica
 * Todo es casi igual, solo realiza la modificacion pertinente para esto
 * @version 1.0
 * @author Kassandra Mirael
 */
public class Filtro implements Semaphore {
    volatile int [] level;
    volatile int [] victim;
    int maxHilosConcurrentes;
    int hilos;
    /**
     * Constructor del Filtro
     * @param hilos El numero de Hilos Permitidos
     * @param maxHilosConcurrentes EL numero de hilos concurrentes simultaneos
     */
    public Filtro(int hilos, int maxHilosConcurrentes) {
        this.maxHilosConcurrentes = maxHilosConcurrentes;
        level = new int[hilos];
        victim = new int[hilos];
        this.hilos=hilos;
        for(int i = 0; i < hilos; ++i){
            level[i] = 0;
        }
    }
    
    /**
     * Metodo que nos retorna el numero de hilos permitidos
     * dentro de la seccion critica.
     * @return El numero de hilos permitido
     */
    @Override
    public int getPermitsOnCriticalSection() {
        return maxHilosConcurrentes;
    }
    
    /**
     * Metodo que adquiere el semaforo.
     */
    @Override
    public void acquire() {
        int i = Integer.parseInt(Thread.currentThread().getName())%hilos;
        for(int j = 1; j < level.length; ++j){
            level[i] = j;
            victim[j] = i;
            /* Aquí tenemos que modificar para permitir un cantidad m
             * de hilos simultaneos en la seccion critica
             */
            
            for(int k = 0; k < level.length; ++k){
                while( existeConflicto(i,j) ){
                    //Espera
                }


            }
        }
    }
    
    /**
     * Metodo nos permite saber si ya se tiene el máximo de hilos conturrentes permitidos 
     * para entrar a la sección crítica.
     * @param i hilo actual
     * @param j nivel en el que se encuentra el hilo.
     * @return boolean true si ya hay maxHilosConcurrentes. false en caso contrario.
     */
    public boolean existeConflicto(int i, int j){
        int numActualHilosConcurrentes = 0;
        for(int k = 0; k < level.length; ++k){
            if((k != i) && (level[k] >= j) && (victim[j] == i)) ++numActualHilosConcurrentes;
            if(numActualHilosConcurrentes==maxHilosConcurrentes){
                
                return true;
                

            } 
        }
        return false;

    }

    /**
     * Metodo que libera el semaforo.
     */
    @Override
    public void release() {
        int i = Integer.parseInt(Thread.currentThread().getName())%hilos;
        level[i] = 0;
       
        
    }
    
}
